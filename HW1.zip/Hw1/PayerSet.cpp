#include "PayerSet.h"
#include <iostream>

PayerSet::PayerSet(){}

bool PayerSet::add(unsigned long accountNum){
    if (set.insert(accountNum))
        return true;
    return false;
}

int PayerSet::size() const{
    return set.size();
}

void PayerSet::print() const{
    for (int i = 0; i < set.size(); i++){
        ItemType nums;
        set.get(i, nums);
        std::cout << nums << std::endl;
    }
}


