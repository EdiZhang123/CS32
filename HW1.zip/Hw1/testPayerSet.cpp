#include "PayerSet.h"
#include <iostream>
#include <cassert>

int main(){
    PayerSet s;
    assert(s.add(12312));
    assert(s.size() == 1);
    s.add(12312);
    assert(s.size() == 1);
    s.add(1231231231);
    s.add(9823823);
    s.add(19283192831);
    s.print();
    
    std::cout << "Passed all tests" << std::endl;
}

