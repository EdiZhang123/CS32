#include "newSet.h"

Set::Set(){
    MAXIMUM_SIZE = DEFAULT_MAX_ITEMS;
    ptr = new ItemType[DEFAULT_MAX_ITEMS];
    m_size = 0;
}
Set::Set(int max_size){
    MAXIMUM_SIZE = max_size;
    ptr = new ItemType[max_size];
    m_size = 0;
}

Set::Set(const Set& other){
    MAXIMUM_SIZE = other.MAXIMUM_SIZE;
    m_size = other.m_size;
    ptr = new ItemType[other.MAXIMUM_SIZE];
    for (int i = 0; i < other.m_size; i++){
        ItemType value;
        other.get(i, value);
        *(ptr + i) = value;
    }
}

Set::~Set(){
    delete [] ptr;
}

Set& Set::operator=(const Set& other)
{
    if (this != &other)
    {
        MAXIMUM_SIZE = other.MAXIMUM_SIZE;
        m_size = other.m_size;
        if (not(ptr == nullptr))
            delete [] ptr;
        ptr = new ItemType[other.MAXIMUM_SIZE];
        for (int i = 0; i < other.m_size; i++){
            ItemType value;
            other.get(i, value);
            *(ptr + i) = value;
        }
    }
    return *this;
}

bool Set::empty() const{
    return m_size == 0;
}

int Set::size() const{
    return m_size;
}

bool Set::insert( const ItemType& value){
    if (m_size >= MAXIMUM_SIZE)
        return false;
    for (int i = 0; i < m_size; i++){
        if (*(ptr + i) == value) //checks if value is already there
            return false;
    }
    *(ptr + m_size) = value;
    m_size ++;
    return true;
}

bool Set::erase( const ItemType& value){
    for (int i = 0; i < m_size; i++){
        if (*(ptr + i) == value){
            for (int k = i; k < m_size-1; k++){
                *(ptr + k) = *(ptr + k+1);
            }
            m_size --;
            return true;
        }
    }
    return false;
}

bool Set::contains( const ItemType& value) const{
    for (int i = 0; i < m_size; i++){
        if (*(ptr + i) == value)
            return true;
    }
    return false;
}

bool Set::get(int i, ItemType& value) const{
    if (not(0 <= i && i < m_size))
        return false;
    else{
        for (int j = 0; j < m_size; j++){
            int count = 0;
            for (int k = 0; k < m_size; k++){
                if (*(ptr + j) < *(ptr + k))
                    count += 1;
            }
            if (count == i){
                value = *(ptr + j);
                return true;
            }
        }
        return false;
    }
}


void Set::swap(Set& other){
    std::swap(MAXIMUM_SIZE, other.MAXIMUM_SIZE);
    std::swap(m_size, other.m_size);
    std::swap(ptr, other.ptr);
}

