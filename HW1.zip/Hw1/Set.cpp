#include "Set.h"
#include <algorithm>

Set::Set(){
    m_size = 0;
}

bool Set::empty() const{
    return m_size == 0;
}

int Set::size() const{
    return m_size;
}

bool Set::insert( const ItemType& value){
    if (m_size >= DEFAULT_MAX_ITEMS)
        return false;
    for (int i = 0; i < m_size; i++){
        if (m_array[i] == value) //checks if value is already there
            return false;
    }
    m_array[m_size] = value;
    m_size ++;
    return true;
}

bool Set::erase( const ItemType& value){
    for (int i = 0; i < m_size; i++){
        if (m_array[i] == value){
            if (i == m_size - 1){
                m_size --;
                return true;
            }
            for (int k = i; k < m_size-1; k++){
                m_array[k] = m_array[k+1];
            }
            m_size --;
            return true;
        }
    }
    return false;
}

bool Set::contains( const ItemType& value) const{
    for (int i = 0; i < m_size; i++){
        if (m_array[i] == value)
            return true;
    }
    return false;
}

bool Set::get(int i, ItemType& value) const{
    if (not(0 <= i && i < m_size))
        return false;
    else{
        for (int j = 0; j < m_size; j++){
            int count = 0;
            for (int k = 0; k < m_size; k++){
                if (m_array[j] < m_array[k])
                    count += 1;
            }
            if (count == i){
                value = m_array[j];
                return true;
            }
        }
        return false;
    }
}


void Set::swap(Set& other){
    std::swap(m_size, other.m_size);
    std::swap(m_array, other.m_array);
}

