#ifndef newSet_h
#define newSet_h

#include <string>

using ItemType = std::string;
const int DEFAULT_MAX_ITEMS = 180;

class Set
{
public:
    Set();

    Set(int max_size);
    
    Set(const Set& other); //copy constructor
    
    ~Set();
    
    Set& operator=(const Set& other);
    
    bool empty() const;  // Return true if the set is empty, otherwise false.
    
    int size () const;    // Return the number of items in the set.
    
    bool insert(const ItemType& value);
   
    
    bool erase( const ItemType& value);
    
    bool contains(const ItemType& value) const;
    // Return true if the value is in the set, otherwise false.
    
    bool get(int i, ItemType& value) const;
    
    void swap(Set& other);
    
private:
    int m_size;
    int MAXIMUM_SIZE;
    ItemType *ptr;
};

#endif


