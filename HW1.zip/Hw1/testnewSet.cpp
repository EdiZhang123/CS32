#include "newSet.h"
#include <iostream>
#include <cassert>
using namespace std;

void test(const Set& uls)
{
    assert(uls.size() == 2);
    assert(uls.contains("audrey"));
    ItemType x = "mom";
    assert(uls.get(0, x)  &&  x == "edi");
    assert(uls.get(1, x)  &&  x == "audrey");
}

int main()
{
    Set s;
    assert(s.insert("edi"));
    assert(s.insert("audrey"));
    test(s);

    Set s1(2);
    assert(s1.empty());
    assert(s1.insert("edi"));
    assert(!s1.insert("edi"));
    assert(s1.insert("audrey"));
    assert(!s1.insert("mom"));
    ItemType y;
    assert(s1.get(0,y));
    assert(!s1.get(2,y));
    assert(y == "edi");
    assert(!s1.erase("dad"));
    assert(s1.erase("edi"));
    assert(!s1.erase("edi"));
    assert(s1.size() == 1);

    Set s2;
    Set s3 = s2;

    assert(s3.empty());
    assert(s3.insert("edi"));
    assert(!s3.insert("edi"));
    assert(s3.insert("audrey"));
    assert(s3.get(0,y));
    assert(!s3.get(2,y));
    assert(y == "edi");
    assert(!s3.erase("dad"));
    assert(s3.erase("edi"));
    assert(!s3.erase("edi"));
    assert(s3.size() == 1);

    cout << "Passed all tests" << endl;
}


/*


 // TESTS FOR unsigned long

 #include "newSet.h"
 #include <iostream>
 #include <cassert>
 using namespace std;

 void test(const Set& uls)
 {
     assert(uls.size() == 2);
     assert(uls.contains(10));
     ItemType x = 10000;
     assert(uls.get(0, x)  &&  x == 20);
     assert(uls.get(1, x)  &&  x == 10);
 }

 int main()
 {
     Set s;
     assert(s.insert(10));
     assert(s.insert(20));
     test(s);

     Set s2;
     Set s3 = s2;
     ItemType y;

     assert(s3.empty());
     assert(s3.insert(10));
     assert(!s3.insert(10));
     assert(s3.insert(20));
     assert(s3.get(0,y));
     assert(!s3.get(2,y));
     assert(y == 20);
     assert(!s3.erase(30));
     assert(s3.erase(20));
     assert(s3.size() == 1);

     cout << "Passed all tests" << endl;
 }

*/
