
#include "Set.h"
#include <string>
#include <iostream>
#include <cassert>
using namespace std;

void test()
{
    Set ss;
    assert(ss.insert("pita"));
    assert(ss.insert("roti"));
    assert(ss.size() == 2);
    assert(ss.contains("roti"));
    ItemType x = "laobing";
    assert(ss.get(0, x)  &&  x == "roti");
    assert(ss.get(1, x)  &&  x == "pita");
    
    Set ss1;
    ss1.insert("edi");
    Set ss2;
    ss2.insert("mom");
    ss2.insert("dad");
    ss1.swap(ss2);
    assert(ss1.size() == 2  &&  ss1.contains("mom")  &&  ss1.contains("dad")  &&
    ss2.size() == 1  &&  ss2.contains("edi"));
    assert(ss1.get(0, x));
    assert(x == "mom");
    assert(ss1.get(1, x));
    assert(x == "dad");
    assert(!ss1.get(-1,x));
    assert(!ss1.empty() && !ss2.empty());
    assert(!ss1.erase("edi"));
    ss1.erase("mom");
    assert(ss1.size() == 1 && ss1.contains("dad"));
    assert(ss1.get(0, x));
    assert(x == "dad");
    assert(!ss1.get(1, x));
    
    
    Set ss3;
    assert(ss3.empty());
    assert(!ss3.erase("audrey"));
    assert(ss3.insert("audrey"));
    assert(!ss3.empty());
    assert(ss3.size() == 1);
    assert(ss3.erase("audrey"));
    assert(ss3.empty());
    
}

int main()
{
    test();
    cout << "Passed all tests" << endl;
}



 /*
  
//TESTS WITH unsigned long
  
 #include "Set.h"
 #include <iostream>
 #include <cassert>
 
 int main()
 {
 
 Set ss1;
 ss1.insert(1029);
 Set ss2;
 ss2.insert(3192);
 ss2.insert(1209388);
 ss1.swap(ss2);
 assert(ss1.size() == 2  &&  ss1.contains(3192)  &&  ss1.contains(1209388)  &&
 ss2.size() == 1  &&  ss2.contains(1029));
 ItemType x;
 assert(ss1.get(0, x));
 assert(x == 1209388);
 assert(ss1.get(1, x));
 assert(x == 3192);
 assert(!ss1.get(-1,x));
 assert(!ss1.empty() && !ss2.empty());
 assert(!ss1.erase(1029));
 ss1.erase(3192);
 assert(ss1.size() == 1 && ss1.contains(1209388));
 assert(ss1.get(0, x));
 assert(x == 1209388);
 assert(!ss1.get(1, x));
 
 
 Set ss3;
 assert(ss3.empty());
 assert(!ss3.erase(123));
 assert(ss3.insert(123));
 assert(!ss3.empty());
 assert(ss3.size() == 1);
 assert(ss3.erase(123));
 assert(ss3.empty());
 
 std::cout << "Passed all tests" << std::endl;
 return 0;
 }
 
*/
