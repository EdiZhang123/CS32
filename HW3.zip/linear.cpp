//#include <string>
//#include <cassert>
//#include <iostream>
//using namespace std;
//
//
//bool somePredicate(string s){
//    int nDigits = 0;
//    for (int k = 0; k != s.size(); k++)
//    {
//        if (isdigit(s[k]))
//            nDigits++;
//    }
//    return nDigits == 3;
//}

bool allFalse(const string a[], int n){ // a is a pointer to the 0th element
    // base case is if n = 0
    if (n <= 0)
        return true;
    if (!somePredicate(*a)){
        if (allFalse(a+1, n-1)){
            return true;
        }
    }
    return false;
}

int countFalse(const string a[], int n){
    // base case is if n = 0
    if (n <= 0)
        return 0;
    if (!somePredicate(*a))
        return 1 + countFalse(a+1, n-1);
    return countFalse(a+1, n-1);
}

int firstFalse(const string a[], int n){
    if (n <= 0)
        return -1;
    if (somePredicate(*a)){
        if (firstFalse(a + 1, n - 1) == -1)
            return -1;
        return firstFalse(a + 1, n - 1) + 1;
    }
    return 0;
}

int indexOfMax(const string a[], int n){
    if (n <= 0)
        return -1;
    if (n == 1)
        return 0;
    if (*a >= *(a + 1 + indexOfMax(a+1, n-1)))
        return 0;
    return indexOfMax(a+1, n-1) + 1;
}

bool has(const string a[], int n1, const string a2[], int n2){
    if (n2 < 1)
        return true;
    if (n1 < 1)
        return false;
    if (*a == *a2)
        return has(a + 1, n1 - 1, a2 + 1, n2 - 1);
    return has(a + 1, n1 - 1, a2, n2);
}

//int main(){
//    string a[] = {"john", "amy", "ketanji" ,"sonia", "amy", "ketanji", "elena"};
//    string a2[] = {"john" , "sonia", "sonia"};
//    string f1[] = {"123","122","2442","131","123"};
//    string f2[] = {"1231","1222","3242","1331","123"};
//    string f3[] = {"131","122","242","331","123"};
//
//
//    //test allFalse
//    assert(!allFalse(f1, 3));
//    assert(allFalse(f2, 4));
//    assert(allFalse(f2, 3));
//    assert(!allFalse(f2, 5));
//    assert(allFalse(f2, -1));
//    assert(allFalse(f2, 0));
//
//    //test countFalse
//    assert(countFalse(f1, 5) == 1);
//    assert(countFalse(f1, 4) == 1);
//    assert(countFalse(f1, 2) == 0);
//    assert(countFalse(f1, 0) == 0);
//    assert(countFalse(f1, -1) == 0);
//    assert(countFalse(f2, 5) == 4);
//    assert(countFalse(f2, 2) == 2);
//    assert(countFalse(f2, 0) == 0);
//    assert(countFalse(f1, 5) == 1);
//    assert(countFalse(f1, 3) == 1);
//    assert(countFalse(f1, 2) == 0);
//
//    //test firstFalse
//    assert(firstFalse(f1, 5) == 2);
//    assert(firstFalse(f1, 3) == 2);
//    assert(firstFalse(f1, 2) == -1);
//    assert(firstFalse(f2, 5) == 0);
//    assert(firstFalse(f2, 2) == 0);
//    assert(firstFalse(f2, 0) == -1);
//    assert(firstFalse(f3, 5) == -1);
//
//    //test indexOfMax
//    assert(indexOfMax(a, 7) == 3);
//    assert(indexOfMax(a, 4) == 3);
//    assert(indexOfMax(a, 3) == 2);
//    assert(indexOfMax(a2, 3) == 1);
//
//    //test has
//    string h1[] = {"a","b","b","c","d"};
//    string h2[] = {"a","b"};
//    string h3[] = {"b","a"};
//    string h4[] = {"a","b","b","c","d"};
//
//    assert(!has(a, 7, a2, 3));
//    assert(has(a, 7, a2, 2));
//    assert(!has(h1, 5, h3, 2));
//    assert(!has(h1, 1, h2, 2));
//    assert(has(h1, 2, h2, 2));
//    assert(!has(h1, 2, h3, 2));
//    assert(has(h1, 2, h4, 2));
//    assert(has(h1, 5, h4, 5));
//    assert(has(h2, 2, h4, 2));
//    assert(has(h1, 4, h4, 2));
//    assert(!has(h1, 4, h4, 5));
//    assert(has(h1, 5, h4, 4));
//    assert(has(h1, 5, h4, 0));
//    assert(has(h1, 5, h4, -1));
//    assert(!has(h1, 2, h4, 3));
//    assert(has(h1, -2, h4, -3));
//    assert(!has(h1, -2, h4, 5));
//
//    cout << "Passed all tests" << endl;
//}
