#include <stack>
#include <iostream>

using namespace std;


class Coord
{
public:
    Coord(int rr, int cc) : m_row(rr), m_col(cc) {}
    int r() const { return m_row; }
    int c() const { return m_col; }
private:
    int m_row;
    int m_col;
};


bool pathExists(char maze[][10], int sr, int sc, int er, int ec){
    stack<Coord> coordStack;      // declare a stack of Coords
    coordStack.push(Coord(sr,sc));
    maze[sr][sc] = '0';
    while (!coordStack.empty())
    {
        Coord current = coordStack.top();
        coordStack.pop();
        if (current.r() == er && current.c() == ec)
            return true;
        else{
            if (maze[current.r()][current.c() + 1] == '.'){ //Move east
                coordStack.push(Coord(current.r(), current.c() + 1));
                maze[current.r()][current.c() + 1] = '0';
            }
            if (maze[current.r() + 1][current.c()] == '.'){ //Move south
                coordStack.push(Coord(current.r() + 1, current.c()));
                maze[current.r() + 1][current.c()] = '0';
            }

            if (maze[current.r()][current.c() - 1] == '.'){ //Move west
                coordStack.push(Coord(current.r(), current.c() - 1));
                maze[current.r()][current.c() - 1] = '0';
            }
            if (maze[current.r() - 1][current.c()] == '.'){ //Move north
                coordStack.push(Coord(current.r() - 1, current.c()));
                maze[current.r() - 1][current.c()] = '0';
            }
        }
    }
    return false; //no solution
}


//int main()
//{
//char maze[10][10] = {
//{ 'X','X','X','X','X','X','X','X','X','X' },
//{ 'X','.','.','.','X','.','.','X','.','X' },
//{ 'X','.','X','X','X','.','.','.','.','X' },
//{ 'X','.','X','.','X','X','X','X','.','X' },
//{ 'X','X','X','.','.','.','.','.','.','X' },
//{ 'X','.','.','.','X','.','X','X','.','X' },
//{ 'X','.','X','.','X','.','.','X','.','X' },
//{ 'X','.','X','X','X','X','.','X','.','X' },
//{ 'X','.','.','X','.','.','.','X','.','X' },
//{ 'X','X','X','X','X','X','X','X','X','X' }
//};
//
//if (pathExists(maze, 4,3, 1,8))
//cout << "Solvable!" << endl;
//else
//cout << "Out of luck!" << endl;
//}


