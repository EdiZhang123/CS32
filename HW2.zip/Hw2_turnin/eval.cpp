#include <string>
#include <stack>
#include <cassert>
#include <iostream>
using namespace std;

int evaluate(string infix, string& postfix, bool& result){
    if (infix.size() == 0)
        return 1;
    string no_spaces;
    for (size_t i = 0; i < infix.size(); i++) { // Take care of spaces
        char c = infix[i];
        if (c != ' ') {
            no_spaces += c;
        }
    }
    if (no_spaces.size() == 0)
        return 1;
    char current;
    int closed = 0;
    bool wasOperand = false, wasBinOperator = false, wasUnary = false, wasClosedPar = false;
    bool canBeOperand = true, canBeBinOperator = false, canBeUnary = true, canBeOpenPar = true, canBeClosedPar = false;
    
    for (size_t i = 0; i < no_spaces.size(); i++){ // 01234
        current = no_spaces[i];
        if (current != '&' && current != '!' && current != '(' && current != ')' && current != '|'
            && current != 'T' && current != 'F')// Cannot have random characters
            return 1;
        if ((current == '&' || current == '|') && !canBeBinOperator)   // Adjacent operators &&, &|, |&, ||
            return 1;
        if ((current == 'T' || current == 'F') && !canBeOperand)  // Adjacent operands TF, TT, FF, FT
            return 1;
        if ((current == '(' && !canBeOpenPar))// Empty parentheses
            return 1;
        if ((current == ')' && !canBeClosedPar))   // Binary operator without operands surrounding (unless it is a ! after)
            return 1;
        if (current == '!' && !canBeUnary)// ) followed by operand, ) must be followed by |, &
            return 1;
        if (current == '('){ // check for open parenthesese
            closed += 1;
            canBeClosedPar = false; canBeOpenPar = true; canBeUnary = true; canBeOperand = true; canBeBinOperator = false;
            wasUnary = false; wasOperand = false; wasClosedPar = false; wasBinOperator = false;
        }
        else if (current == ')'){
            wasClosedPar = true; wasUnary = false; wasOperand = false; wasBinOperator = false;
            closed -= 1;
            canBeClosedPar = true; canBeUnary = false; canBeOperand = false; canBeBinOperator = true; canBeOpenPar = false;
        }
        else if (current == '&' || current == '|'){
            canBeClosedPar = false; canBeOpenPar = true; canBeUnary = true; canBeBinOperator = false;
            if (wasOperand || wasClosedPar)
                canBeOperand = true;
            else{
                canBeOperand = false;}
            wasBinOperator = true; wasUnary = false; wasOperand = false; wasClosedPar = false;
        }
        else if ((current == 'T' || current == 'F')){
            canBeOpenPar = false; canBeClosedPar = true; canBeOperand = false; canBeBinOperator = true;
            wasOperand = true; wasBinOperator = false; wasUnary = false; wasClosedPar = false;
        }
        else if (current == '!'){
            canBeUnary = true; canBeOperand = true; canBeOpenPar = true; canBeClosedPar = false;
            wasUnary = true; wasOperand = false; wasClosedPar = false; wasBinOperator = false;
        }
    }
    if (closed != 0 || wasBinOperator || wasUnary)    // Cannot end on !, (, |, &
        return 1;
    
    //Convert to postfix
    postfix = "";
    stack<char> op_stack;
    for (size_t i = 0; i < no_spaces.size(); i++) {
        switch (no_spaces[i]){
            case 'F':
            case 'T':
                if (!op_stack.empty() && op_stack.top() == '!'){
                    postfix += no_spaces[i];
                    postfix += op_stack.top();
                    op_stack.pop();
                }
                else
                    postfix += no_spaces[i];
                break;
            case '(':
                op_stack.push(no_spaces[i]);
                break;
            case ')':
                while (!op_stack.empty() && op_stack.top() != '(') {
                    postfix += op_stack.top();
                    op_stack.pop();
                }
                op_stack.pop();
                if (!op_stack.empty() && op_stack.top() == '!'){
                    postfix += op_stack.top();
                    op_stack.pop();
                }
                break;
            case '&':
            case '|':
                while (!op_stack.empty() && op_stack.top() != '(' && no_spaces[i] >= op_stack.top()){
                    postfix += op_stack.top();
                    op_stack.pop();
                }
                op_stack.push(no_spaces[i]);
                break;
            case '!':
                op_stack.push(no_spaces[i]);
        }
    }
    while (!op_stack.empty()){
        postfix += op_stack.top();
        op_stack.pop();
    }
    
    //Evaluate
    stack<char> operand;
    for (size_t i = 0; i < postfix.size(); i++){
        if (postfix[i] == 'T' || postfix[i] == 'F')
            operand.push(postfix[i]);
        else if (postfix[i] == '!'){
            char operand0 = operand.top();
            operand.pop();
            if (operand0 == 'T')
                operand.push('F');
            else
                operand.push('T');
        }
        else if (postfix[i] == '&'){
            char operand2 = operand.top();
            operand.pop();
            char operand1 = operand.top();
            operand.pop();
            if (operand2 == 'F' || operand1 == 'F')
                operand.push('F');
            else if (operand1 == 'T' && operand2 == 'T')
                operand.push('T');
        }
        else if (postfix[i] == '|'){
            char operand2 = operand.top();
            operand.pop();
            char operand1 = operand.top();
            operand.pop();
            if (operand2 == 'T' || operand1 == 'T')
                operand.push('T');
            else
                operand.push('F');
        }
    }
                 
    if (operand.size() == 1 && operand.top() == 'T')
        result = true;
    else if (operand.size() == 1 && operand.top() == 'F')
        result = false;

    return 0;
}


//int main()
//{
//    string pf;
//    bool answer;
//    assert(evaluate("T| F", pf, answer) == 0  &&  pf == "TF|"  &&  answer);
//    assert(evaluate("", pf, answer) == 1);
//    assert(evaluate("T|", pf, answer) == 1);
//    assert(evaluate("F F", pf, answer) == 1);
//    assert(evaluate("TF", pf, answer) == 1);
//    assert(evaluate("()", pf, answer) == 1);
//    assert(evaluate("()T", pf, answer) == 1);
//    assert(evaluate("T(F|T)", pf, answer) == 1);
//    assert(evaluate("T(&T)", pf, answer) == 1);
//    assert(evaluate("(T&(F|F)", pf, answer) == 1);
//    assert(evaluate("T+F", pf, answer) == 1);
//    assert(evaluate("F  |  !F & (T&F) ", pf, answer) == 0 &&  pf == "FF!TF&&|"  &&  !answer);
//    assert(evaluate(" F  ", pf, answer) == 0 &&  pf == "F"  &&  !answer);
//    assert(evaluate("((T))", pf, answer) == 0 &&  pf == "T"  &&  answer);
//    assert(evaluate("((F))", pf, answer) == 0 &&  pf == "F"  &&  !answer);
//    assert(evaluate("!F|(F&T)", pf, answer) == 0 &&  pf == "F!FT&|"  &&  answer);
//    assert(evaluate("((T))", pf, answer) == 0 &&  pf == "T"  &&  answer);
//    assert(evaluate("((T))", pf, answer) == 0 &&  pf == "T"  &&  answer);
//    assert(evaluate("!!(F|T)", pf, answer) == 0 && pf == "FT|!!" && answer);
//    assert(evaluate("T&!F", pf, answer) == 0 && answer);
//    assert(evaluate("T|F&F", pf, answer) == 0 && answer);
//    assert(evaluate("!F|T", pf, answer) == 0 && answer);
//    assert(evaluate("T", pf, answer) == 0 && pf == "T" && answer);
//    assert(evaluate("T & !(F | T & T | F) | !!!(F & T & F) ", pf, answer) == 0 && answer);
//    assert(evaluate("T", pf, answer) == 0 && pf == "T" && answer);
//    assert(evaluate("F", pf, answer) == 0 && pf == "F" && !answer);
//    assert(evaluate("!", pf, answer) == 1);
//    assert(evaluate("|", pf, answer) == 1);
//    assert(evaluate("&", pf, answer) == 1);
//    assert(evaluate("(", pf, answer) == 1);
//    assert(evaluate(")", pf, answer) == 1);
//    assert(evaluate("", pf, answer) == 1);
//    assert(evaluate("A", pf, answer) == 1);
//    assert(evaluate("TF", pf, answer) == 1);
//    assert(evaluate(" !    !!!!!! F  ", pf, answer) == 0);
//    assert(evaluate("T|F", pf, answer) == 0 && pf == "TF|" && answer);
//    assert(evaluate(" T | F ", pf, answer) == 0 && pf == "TF|" && answer);
//    assert(evaluate("T&F", pf, answer) == 0 && pf == "TF&" && !answer);
//    assert(evaluate(" T & F ", pf, answer) == 0 && pf == "TF&" && !answer);
//    assert(evaluate("!T", pf, answer) == 0 && pf == "T!" && !answer);
//    assert(evaluate(" ! T ", pf, answer) == 0 && pf == "T!" && !answer);
//    assert(evaluate("(T)", pf, answer) == 0 && pf == "T" && answer);
//    assert(evaluate(" ( T ) ", pf, answer) == 0 && pf == "T" && answer);
//    assert(evaluate(" ( T & ! ( F | T & T & ( ! F | F ) ) | F )", pf, answer) == 0 && !answer);
//    assert(evaluate(" T ", pf, answer) == 0);
//    assert(evaluate(" T &   F    ", pf, answer) == 0 && pf == "TF&" && !answer);
//    assert(evaluate("(T&(T&(T&(T&(T&(T&(T&(T&(T)))))))))", pf, answer) == 0 && pf == "TTTTTTTTT&&&&&&&&");
//    assert(evaluate(" ", pf, answer) == 1);
//    assert(evaluate(" T !", pf, answer) == 1);
//    assert(evaluate(" T | &", pf, answer) == 1);
//    assert(evaluate(" ( ) ", pf, answer) == 1);
//    assert(evaluate(" T ( F & F )", pf, answer) == 1);
//    assert(evaluate("T | (F&F|)", pf, answer) == 1);
//    assert(evaluate(" T ( & F ) ", pf, answer) == 1);
//    assert(evaluate(" F | (T) ) ", pf, answer) == 1);
//    assert(evaluate("(((((F)))))", pf, answer) == 0 && pf == "F" && !answer);
//    assert(evaluate("T| F", pf, answer) == 0 && pf == "TF|" && answer);
//    assert(evaluate("", pf, answer) == 1);
//    assert(evaluate("T|", pf, answer) == 1);
//    assert(evaluate("F F", pf, answer) == 1);
//    assert(evaluate("TF", pf, answer) == 1);
//    assert(evaluate("T&!F!)", pf, answer) == 1);
//    assert(evaluate("!!!!!!!!T", pf, answer) == 0 && pf == "T!!!!!!!!" && answer);
//    assert(evaluate("()", pf, answer) == 1);
//    assert(evaluate("()T", pf, answer) == 1);
//    assert(evaluate("T(F|T)", pf, answer) == 1);
//    assert(evaluate("T(&T)", pf, answer) == 1);
//    assert(evaluate("(T&(F|F)", pf, answer) == 1);
//    assert(evaluate("T+F", pf, answer) == 1);
//    assert(evaluate("F  |  !F & (T&F) ", pf, answer) == 0 && pf == "FF!TF&&|" && !answer);
//    assert(evaluate(" F  ", pf, answer) == 0 && pf == "F" && !answer);
//    assert(evaluate("((T))", pf, answer) == 0 && pf == "T" && answer);
//    assert(evaluate("T|F|T", pf, answer) == 0 && pf == "TF|T|" && answer);
//    assert(evaluate("12n42", pf, answer) == 1);
//    assert(evaluate("14&|", pf, answer) == 1);
//    assert(evaluate("     F|!     T|(F|F)", pf, answer) == 0 && pf == "FT!|FF||");
//
//    cout << "Passed all tests" << endl;
//}


