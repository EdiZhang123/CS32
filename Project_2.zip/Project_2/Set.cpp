#include "Set.h"

Set::Set(){
    head = nullptr;
}

Set::Set(const Set& other){     //Copy constructor
    head = nullptr;
    for (Node *p = other.head ; p != nullptr; p = p->next){
        insert(p->data);
    }
}

Set& Set::operator=(const Set& other){
    if (head != other.head){
        Set temp(other);
        Node *p = head;
        head = temp.head;
        temp.head = p;
        p = nullptr;
    }
    return *this;
}

Set::~Set(){
    if (size() == 0)
        ;
    else if (size() == 1)
        delete head;
    else{
        for (Node *p = head->next; p!= nullptr ; p = p->next){
            delete head;
            head = p;
        }
        delete head; //delete last one
    }
}

bool Set::empty() const{
    return head == nullptr;
}

int Set::size() const{
    int count = 0;
    for (Node *p = head; p != nullptr; p = p->next){ //traverse with a new pointer until you find nullptr
        count += 1;
    }
    return count;
}

bool Set::insert(const ItemType& value){
    if (head == nullptr){     //Case 1: empty set
        Node *nextNode = new Node;
        nextNode->data = value;
        head = nextNode;
        nextNode->next = nullptr; //initialize to null
        nextNode->prev = nullptr; //initialize to null
        return true;
    }
    else {       //Case 2: nonempty set
        for (Node *p = head; p != nullptr; p = p->next){ //check if value already exists
            if (p->data == value)
                return false;
        }
        Node *nextNode = new Node;
        nextNode->data = value;
        nextNode->next = head;
        head->prev = nextNode;
        nextNode->prev = nullptr;
        head = nextNode;
        return true;
    }
}

bool Set::erase(const ItemType& value){
    Node *p = head;
    for (; p != nullptr; p = p->next){ //skips loop if head is nullptr (set is empty)
        if (p->data == value && p->prev == nullptr){ // check if erasing first item
            if (p->next == nullptr) { //check if set has only one item
                head = nullptr;
                delete p;
                return true;
            }
            head = p->next;
            p->next->prev = nullptr;
            delete p;
            return true;
        }
        else if (p->data == value && p->prev != nullptr && p->next != nullptr){ //not first/last item
            p->prev->next = p->next;
            p->next->prev = p->prev;
            delete p;
            return true;
        }
        else if (p->data == value && p->next == nullptr){ //last item
            p->prev->next = nullptr;
            delete p;
            return true;
        }
    }
    return false;
}

bool Set::contains(const ItemType& value) const{
    for (Node *p = head; p != nullptr; p = p->next){ //traverse with a new pointer until you find nullptr
        if (p->data == value)
            return true;
    }
    return false;
}

bool Set::get(int pos, ItemType& value) const{
    if (!(0 <= pos && pos < size())){
        return false;
    }
    else{
        for (Node* p1 = head; p1 != nullptr; p1 = p1->next){
            int count = 0;
            for (Node* p2 = head; p2 != nullptr; p2 = p2->next){
                if (p2->data > p1->data)
                    count += 1;
            }
            if (count == pos){
                value = p1->data;
                return true;
            }
        }
        return true;
    }
}

void Set::swap(Set& other){
    Node *p1 = head;
    head = other.head;
    other.head = p1;
}


void unite(const Set& s1, const Set& s2, Set& result){
    Set temp = s1;
    ItemType vals;
    for (int i = 0; i < s2.size(); i++){
        s2.get(i, vals);
        temp.insert(vals);
    }
    result = temp;
}

void inOnlyOne(const Set& s1, const Set& s2, Set& result){
    Set temp = s1;
    ItemType vals;
    for (int i = 0; i < s2.size(); i++){
        s2.get(i, vals);
        if (s1.contains(vals)){
            temp.erase(vals);
        }
        else{
            temp.insert(vals);
        }
    }
    result = temp;
    
}
