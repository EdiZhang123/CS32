void removeEven(list<int>& li)
{
    list<int>::iterator i;
    for (i = li.begin(); i != li.end();) {
        if ((*i) % 2 == 0)
            i = li.erase(i);
        else
            i++;
    }
}
