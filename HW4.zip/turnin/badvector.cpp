void removeBad(vector<Restaurant*>& v)
{
    vector <Restaurant*>::iterator i;
    for (i = v.begin(); i != v.end();) {
        if ((*i) != nullptr) {
            if ((*i)->stars() <= 2) {
                delete *i;
                i = v.erase(i);
            }
            else
                i++;
        }
    }
}


