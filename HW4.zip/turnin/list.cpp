void listAll(const File* f, string path)  // two-parameter overload
{
    if (f->files() == nullptr) { // Pointing at plainfile
        cout << path + "/" + f->name() << endl;
    }
    else { // Pointing at directory
        cout << path + "/" + f->name() << endl;
        const vector<File*>* p = f->files();
        for (vector<File*>::const_iterator it = (*p).begin(); it != (*p).end(); it++)
            listAll((*it), path + "/" + f->name() );

    }
}
