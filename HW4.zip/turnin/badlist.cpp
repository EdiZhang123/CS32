void removeBad(list<Restaurant*>& li)
{
    list<Restaurant*>::iterator i;
    for (i = li.begin(); i != li.end();) {
        if ((*i) != nullptr) {
            if ((*i)->stars() <= 2) {
                delete *i;
                i = li.erase(i);
            }
            else
                i++;
        }
    }
}

