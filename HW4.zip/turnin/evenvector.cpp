void removeEven(vector<int>& v)
{
    vector<int>::iterator i;
    for (i = v.begin(); i != v.end();) {
        if (*i % 2 == 0)
            i = v.erase(i);
        else
            i++;
    }
}
