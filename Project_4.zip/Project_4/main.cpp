#include <iostream>
#include <fstream>
#include <vector>
#include <list>
#include <utility>
#include <string>
#include <functional>
#include <stack>
#include <cmath>
#include <algorithm>
#include <iterator>
#include <cassert>
#include <sstream>

using namespace std;

const int N = 8;

struct HashTable {
    HashTable(size_t size): Sequences(size){}
    vector<list<pair<string, vector<int>>>> Sequences;
    void insertSequence(string key, int offset);
    size_t hashFunction(const string &key);
    vector<int> search(string key);
    bool stringHasOffset(string s, int offset);
    
};

size_t HashTable::hashFunction(const string &key) {
    return hash<string>{}(key) % Sequences.size();
}

void HashTable::insertSequence(string key, int offset) {
    auto& chain = Sequences[hashFunction(key)];
    for (auto& pair : chain) {
        if (key == pair.first) {// Case where sequence already exists
            pair.second.push_back(offset);
            return;
        }
    }
    chain.emplace_back(key, vector<int>{offset}); // Create new vector because sequence doesn't exist
    return;
}

bool HashTable::stringHasOffset(string s, int offset) {
    vector<int> offsets = search(s);
    for (auto i : offsets) {
        if (i == offset)
            return true;
    }
    return false;
}

vector<int> HashTable::search(string key) {
    auto& chain = Sequences[hashFunction(key)];
    for (auto& pair : chain) {
        if (key == pair.first) // Case where sequence is the same
            return pair.second;
    }
    return {}; // Return empty vector because sequence doesn't exist
}

bool isValidRevisionString(string s) { // Check if string is valid
    
    if (!(s[0] == '+' || s[0] == '#' || s[0] == '\n'))
        return false;
    bool isCopyingFirst = false;
    bool isCopyingSecond = false;
    bool isAdding = false;
    char delimiter = NULL;
    for (size_t i = 0; i < s.length();) {
        // char current = s[i];
        if (s[i] != '#' && s[i] != '+' && s[i] != '\n' && !isAdding && !isCopyingFirst && !isCopyingSecond)
            return false;
        if (s[i] == delimiter) {
            isAdding = false;
            delimiter = NULL;
            i++;
        }
        
        else if (s[i] == '+' && !isAdding) {
            if (i + 1 < s.length())
                delimiter = s[i+1];
            isAdding = true;
            i += 2;
        }
        else if (s[i] == '#' && !isAdding) {
            isCopyingFirst = true;
            i++;
        }
        
        else if (s[i] == '\n') {
            i++;
        }
        
        if (isAdding && s[i] != delimiter && i < s.length()) {
            while (isAdding && s[i] != delimiter && i < s.length())
            {
                i++;
            }
            if (i >= s.length())
                return false; // The delimiter never closed, and i traversed beyond the string
            isAdding = false;
            delimiter = NULL;
            i++;
        }
        
        while (isCopyingSecond && i < s.length())
        {
            if ('0' <= s[i] && s[i] <= '9')
                i++;
            else if (s[i] == '+') {
                isCopyingSecond = false;
                isAdding = true;
                if (i + 1 < s.length())
                    delimiter = s[i+1];
                i += 2;
            }
            else if (s[i] == '#') {
                isCopyingSecond = false;
                isCopyingFirst = true;
                i++;
            }
            else if (s[i] == '\n') {
                if (i+1 == s.length()) {
                    return true;
                }
                else if ( i + 1 < s.length()) {
                    if ( s[i+1] != '+' || s[i+1] != '#')
                        return false;
                }
                else
                    i++;
            }
            else
                return false;
        }
        
        while (isCopyingFirst && i < s.length())  // is copying, needs values between 0-9
        {
            if ('0' <= s[i] && s[i] <= '9')
                i++;
            else if (s[i] == ',' && s[i-1] != '#') {
                isCopyingFirst = false;
                isCopyingSecond = true;
                i++;
            }
            else
                return false;
        }
        
        
    }
    if (isAdding || isCopyingFirst)
        return false;
    return true;
}



bool revise(istream& fold, istream& frevision, ostream& fnew) {
    
    string old((istreambuf_iterator<char>(fold)), istreambuf_iterator<char>());
    string s((istreambuf_iterator<char>(frevision)), istreambuf_iterator<char>());

    if (!isValidRevisionString(s)) {
        cerr << "Invalid string" << endl;
        return false;
    }
    
    string temp = "";
    size_t i = 0;
    while (i < s.length()) {
        if (i < s.length() && (s[i] == 'r' || s[i] == '\n'))
            i++;
        if (i < s.length() && s[i] == '+' ) {
            char delimiter = s[i+1];
            i += 2;
            while (s[i] != delimiter) {
                temp += s[i];
                i++;
            }
            i++;
        }
            //Add whatever is between delimiters
        if (i < s.length() && s[i] == '#') {
            stack<int> offsets;
            stack<int> lengths;
            
            i++;
            while (s[i] != ',') {
                offsets.push(s[i] - '0');
                i++;
            }
            // After while loop, char at i is ‘,’
            i++;
            while (i < s.length() && isdigit(s[i])) {
                lengths.push(s[i] - '0');
                i++;
            }
            int offset = 0;
            int length = 0;
            int j = 0;
            while (!offsets.empty()) {
                offset += offsets.top() * pow(10, j++);
                offsets.pop();
            }
            j = 0;
            while (!lengths.empty()) {
                length += lengths.top() * pow(10, j++);
                lengths.pop();
            }
            if (offset + length > old.length())
                return false;
            for (int k = offset; k < offset + length; k++)
                temp += old[k];
        }
    }
    fnew << temp;
    return true;
}

void createRevision(istream& fold, istream& fnew, ostream& frevision) {
    string oldString((istreambuf_iterator<char>(fold)), istreambuf_iterator<char>());
    string newString((istreambuf_iterator<char>(fnew)), istreambuf_iterator<char>());

    
    string revisionString = "";
    string endExtras = "";
    HashTable table(oldString.size()); // Create hashtable
    for (int i = 0; i < oldString.size() - N + 1; i++) {
        
        string substring = "";
        for (int j = 0; j < N; j++) {
            substring += oldString[i+j];
        }
        table.insertSequence(substring, i); // Insert all subsequences into hash table
    }
    
    
    // Compare substrings of length N from newString
    for (int i = 0; i < newString.size();) {
        char delimeter = '/';
        string addstring = "";
        
        // Next, hash the substring to get the offsets
        if (i > newString.size() - N) {
            string s = newString.substr(i, newString.size() - i);
            for (int k = 0; k < s.size(); k++) {
                if (s[k] == delimeter) {
                    delimeter++;
                    k = -1;
                }
            }
            revisionString += '+';
            revisionString += delimeter;
            revisionString += s;
            revisionString += delimeter;
            i += s.size();
            break;
        }
        
        vector<int> offsets = table.search(newString.substr(i, N));
        
        if (offsets.size() == 0) { // no substring in the hash table, so just add that character
            while (offsets.size() == 0) {
                if (i == newString.size() - N) { // Last substring
                    addstring += newString.substr(i, N);
                    //break;
                    i += N;
                }
                else
                    addstring += newString.substr(i, N)[0];
                i++;
                if (i + N <= newString.size())
                    offsets = table.search(newString.substr(i, N));
                else
                    break;
            }
            revisionString += "+";
            
            for (int k = 0; k < addstring.size(); k++) {
                if (addstring[k] == delimeter) {
                    delimeter++;
                    k = -1;
                }
            }
            revisionString += string(1, delimeter);
            revisionString += addstring;
            revisionString += string(1, delimeter);
        }
        
        else { // substring is in the hash table
            int offsetWithMaxShifts = offsets[0];
            int maxShifts = 0;
            for (int off : offsets) {
                int shifts = 0;
                while (off + shifts <= oldString.size() - N && oldString.substr(off + shifts, N) == newString.substr(i + shifts, N)) {
                    shifts++;
                }
                if (shifts > maxShifts) {
                    maxShifts = shifts;
                    offsetWithMaxShifts = off;
                }
            }
            int numToCopy = N + maxShifts - 1;
            if (numToCopy >= 0) {
                string copy = to_string(offsetWithMaxShifts);
                string length = to_string(numToCopy);
                revisionString += "#" + copy + "," + length;
            }
            i += numToCopy;
        }

    }
  
    //cerr << revisionString << endl;
    frevision << revisionString;
}

//bool runtest(string oldName, string newName, string revisionName, string newName2)
//    {
//        if (revisionName == oldName  ||  revisionName == newName  ||
//            newName2 == oldName  ||  newName2 == revisionName  ||
//                newName2 == newName)
//        {
//            cerr << "Files used for output must have names distinct from other files" << endl;
//            return false;
//        }
//        ifstream oldFile(oldName, ios::binary);
//        if (!oldFile)
//        {
//            cerr << "Cannot open " << oldName << endl;
//            return false;
//        }
//        ifstream newFile(newName, ios::binary);
//        if (!newFile)
//        {
//            cerr << "Cannot open " << newName << endl;
//            return false;
//        }
//        ofstream revisionFile(revisionName, ios::binary);
//        if (!revisionFile)
//        {
//            cerr << "Cannot create " << revisionName << endl;
//            return false;
//        }
//        createRevision(oldFile, newFile, revisionFile);
//        revisionFile.close();
//
//        oldFile.clear();   // clear the end of file condition
//        oldFile.seekg(0);  // reset back to beginning of the file
//        ifstream revisionFile2(revisionName, ios::binary);
//        if (!revisionFile2)
//        {
//            cerr << "Cannot read the " << revisionName << " that was just created!" << endl;
//            return false;
//        }
//        ofstream newFile2(newName2, ios::binary);
//        if (!newFile2)
//        {
//            cerr << "Cannot create " << newName2 << endl;
//            return false;
//        }
//        assert(revise(oldFile, revisionFile2, newFile2));
//        newFile2.close();
//
//        newFile.clear();
//        newFile.seekg(0);
//        ifstream newFile3(newName2, ios::binary);
//        if (!newFile)
//        {
//            cerr << "Cannot open " << newName2 << endl;
//            return false;
//        }
//        if ( ! equal(istreambuf_iterator<char>(newFile), istreambuf_iterator<char>(),
//                     istreambuf_iterator<char>(newFile3), istreambuf_iterator<char>()))
//        {
//            cerr << newName2 << " is not identical to " << newName
//                     << "; test FAILED" << endl;
//            return false;
//        }
//        return true;
//    }
//
//    int main()
//    {
//        assert(runtest("/Users/edizhang/Desktop/strange1.txt", "/Users/edizhang/Desktop/strange2.txt", "/Users/edizhang/Desktop/revision.txt", "/Users/edizhang/Desktop/newFile.txt"));
//        cerr << "Test PASSED" << endl;
//    }

//int main() {
//    ifstream oldFile("/Users/edizhang/Desktop/greeneggs1.txt");
//
//    if ( ! oldFile )                // Did opening the file fail?
//    {
//        cerr << "Error: Cannot open!" << endl;
//    }
//
//
//
//    ifstream newFile("/Users/edizhang/Desktop/greeneggs2.txt");
//    if ( ! newFile )                // Did opening the file fail?
//    {
//        cerr << "Error: Cannot open!" << endl;
//    }
//
//
//    ofstream revisionFile("/Users/edizhang/Desktop/revision.txt");
//    if ( ! revisionFile )           // Did the creation fail?
//        {
//            cerr << "Error: Cannot create revision.txt!" << endl;
//        }
////    revisionFile << "This will be written to the file" << endl;
////    revisionFile << "2 + 2 = " << 2+2 << endl;
//
//
//
//    createRevision(oldFile, newFile, revisionFile);
//    revisionFile.close();
//    oldFile.clear();   // clear the end of file condition
//    oldFile.seekg(0);  // reset back to beginning of the file
//
//    ifstream revisionFile2("/Users/edizhang/Desktop/revision.txt");
//    if ( ! revisionFile2)
//    {
//        cerr << "Cannot create revisionFile2.txt" << endl;
//    }
//
//    ofstream writtenFile("/Users/edizhang/Desktop/newFile.txt");
//    if ( ! writtenFile)
//    {
//        cerr << "Cannot create newFile.txt" << endl;
//    }
//
//
//    revise(oldFile, revisionFile2, writtenFile);
//
//}

//
//int main() {
//    assert(isValidRevisionString("+//"));
//    assert(!isValidRevisionString("+///"));
//    assert(isValidRevisionString("+/(ijkjk+++++akskab/"));
//    assert(isValidRevisionString("+/#0,2+/+//"));
//    assert(!isValidRevisionString("+a#0,2+/+//"));
//    assert(isValidRevisionString("+a#0,2+/+//a"));
//    assert(!isValidRevisionString("+a#0,2+/a+//a"));
//    assert(!isValidRevisionString("#9,+a#0,2+/a+//a"));
//    assert(isValidRevisionString("#9,0+a#0,2+/+//a"));
//    assert(!isValidRevisionString("#9,2\n93+a#0,2+/+//a"));
//    assert(isValidRevisionString("+/XY/#0,12+/ETC/#13,13+:QQ/OK:"));
//    assert(isValidRevisionString("\n\n\n\n"));
//    assert(isValidRevisionString("+/XYA/#1,9+?BLETCH?#14,12+ZQQ/OKZ"));
//    assert(isValidRevisionString("+=XYABCDEFGHIJBLETCHPQRSTUVPQRSTQQ/OK="));
//    assert(isValidRevisionString("+/++\n/#0,2"));
//    assert(!isValidRevisionString("+/++\n/#0\n,2"));
//    assert(!isValidRevisionString("+/++\n/#0\n,2\n"));
//    assert(!isValidRevisionString("#0\n,\n"));
//    assert(!isValidRevisionString("#0\n"));
//    assert(!isValidRevisionString("#\n,\n"));
//    assert(!isValidRevisionString(""));
//    assert(isValidRevisionString("\n#9,98"));
//    assert(isValidRevisionString("#442,68#51,11#33,19#0,33#95,31#155,34#124,32#193,29#62,53#241,269"));
//    assert(isValidRevisionString("#34508,8#16,9+/ of Carey's revised ver/#6798,8+/War and Peace!/#74743,1891#26,19+/David and Car/#42452,9#67,2527#6575,8#2601,1038+/desir/#3643,227+/desir/#3874,2062#7493,10039#6575,8#17539,3902#6575,8#21448,8508#6575,8#29963,4859#35890,156+/David and Carey/#36061,2080#6575,8#38148,6902#6575,8#45057,19316#6575,8#64380,10370#5941,374#6575,8#6322,878#6575,8#7207,286#34822,1067"));
//    assert(isValidRevisionString("#108,48#123,233#225,29#108,48#123,233#225,29#108,48#123,233#225,29#108,48#123,233#225,29#108,48#123,233#225,29#108,48#123,233#225,29#108,48#123,233#225,29#108,48"));
//
//
//
//    cerr << "Passed" << endl;
//
//
//}





void runtest(string oldtext, string newtext)
    {
        istringstream oldFile(oldtext);
        istringstream newFile(newtext);
        ostringstream revisionFile;
        createRevision(oldFile, newFile, revisionFile);
        string result = revisionFile.str();
        cerr << "The revision file length is " << result.size()
             << " and its text is " << endl;
        cerr << result << endl;

        oldFile.clear();   // clear the end of file condition
        oldFile.seekg(0);  // reset back to beginning of the stream
        istringstream revisionFile2(result);
        ostringstream newFile2;
        assert(revise(oldFile, revisionFile2, newFile2));
        string dd = newFile2.str();
        assert(newtext == newFile2.str());
    }

    int main()
    {
        runtest("There's a bathroom on the right.",
                "There's a bad moon on the rise.");
        runtest("ABCDEFGHIJBLAHPQRSTUVPQRSTUV",
                "XYABCDEFGHIJBLETCHPQRSTUVPQRSTQQ/OK");
        cerr << "All tests passed" << endl;
    }
