#include "History.h"
#include <iostream>
using namespace std;

History::History(int nRows, int nCols): m_rows(nRows),m_cols(nCols){
    for (int r = 0; r < nRows; r++)
        for (int c = 0; c < nCols; c++)
            grid[r][c] = '.'; //fill with dots first
};

bool History::record(int r, int c)
{
    if (r> m_rows || c> m_cols || r <= 0 || c <= 0)
        return false;
    else
    {
        if (grid[r-1][c-1] == '.')
            grid[r-1][c-1] = 'A';
        else if (grid[r-1][c-1] != 'Z')
            grid[r-1][c-1] ++;
        return true;
    }
}

void History::display() const {
    clearScreen();
    
    for (int r = 0; r < m_rows; r++)
    {
        for (int c = 0; c < m_cols; c++){
            cout << grid[r][c];}
        cout << endl;
    }
    cout << endl;
}
